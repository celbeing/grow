from django.apps import AppConfig


class students_appConfig(AppConfig):
    name = 'students_app'
